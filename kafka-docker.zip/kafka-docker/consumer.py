from confluent_kafka import Consumer  
import psycopg2  
import json  
import logging  

# Set up logging  
logging.basicConfig(level=logging.ERROR)  

# Kafka setup  
consumer = Consumer({  
    'bootstrap.servers': 'localhost:9092',  
    'group.id': 'grp14',  
    'auto.offset.reset': 'earliest'  
})  

consumer.subscribe(['pyscript'])  

# PostgreSQL setup  
conn = psycopg2.connect(  
    host="localhost",  
    database="postgres",  
    user="yesitsme",  
    password="Darshan123"  
)  

# Create a new table if it doesn't exist  
with conn.cursor() as cursor:  
    cursor.execute('''  
    CREATE TABLE IF NOT EXISTS consumer (  
        id SERIAL PRIMARY KEY,  
        name VARCHAR(100),  
        age INT  
    )  
    ''')  
    conn.commit()  

while True:  
    print("Polling for messages...")  
    msg = consumer.poll(1.0)  
    if msg is None:  
        print("No messages received")  
        continue  
    elif msg.error():  
        print(f"Error: {msg.error()}")  
        continue  

    print("Received message")  
    change = json.loads(msg.value().decode('utf-8'))  
    
    # Log the incoming message to see its structure  
    print(f"Incoming message: {change}")  

    # Check if the expected keys are present  
    if 'operation' not in change:  
        print("Received message does not have 'operation' key, skipping...")  
        continue  

    try:  
        with conn.cursor() as cursor:  
            # Handle the change based on the operation  
            if change['operation'] == 'insert':  
                cursor.execute('''  
                INSERT INTO consumer (id, name, age) VALUES (%s, %s, %s)  
                ON CONFLICT (id) DO UPDATE SET name = %s, age = %s  
                ''', (change['id'], change['name'], change['age'], change['name'], change['age']))  
                print(f"Inserted/Updated Message: {change}")  
            elif change['operation'] == 'delete':  
                cursor.execute('DELETE FROM consumer WHERE id = %s', (change['id'],))  
                print(f"Deleted Message: {change}")  
            elif change['operation'] == 'update':  
                cursor.execute('UPDATE consumer SET name = %s, age = %s WHERE id = %s', (change['name'], change['age'], change['id']))  
                print(f"Updated Message: {change}")  

            conn.commit()  
    except Exception as e:  
        logging.error(f"Error processing message: {e}")  
        conn.rollback()  # Rollback the transaction on error  

# Close the PostgreSQL connection  
conn.close()





# from confluent_kafka import Consumer
# import psycopg2
# import json

# # Kafka setup
# consumer = Consumer({
#     'bootstrap.servers': 'localhost:9092',
#     'group.id': 'grp14',
#     'auto.offset.reset': 'earliest'
# })

# consumer.subscribe(['pyscript'])

# # PostgreSQL setup
# conn = psycopg2.connect(
#     host="localhost",
#     database="postgres",
#     user="yesitsme",
#     password="Darshan123"
# )

# cursor = conn.cursor()

# # Create a new table if it doesn't exist
# cursor.execute('''
# CREATE TABLE IF NOT EXISTS consumer (
#     id SERIAL PRIMARY KEY,
#     name VARCHAR(100),
#     age INT
# )
# ''')

# while True:
#     print("Polling for messages...")
#     msg = consumer.poll(1.0)
#     if msg is None:
#         print("No messages received")
#         continue
#     elif msg.error():
#         print(f"Error: {msg.error()}")
#     else:
#         print("Received message")
#         change = json.loads(msg.value().decode('utf-8'))

#         # Handle the change based on the operation
#         if change['operation'] == 'insert':
#             cursor.execute('''
#             INSERT INTO consumer (id, name, age) VALUES (%s, %s, %s)
#             ON CONFLICT (id) DO UPDATE SET name = %s, age = %s
#             ''', (change['id'], change['name'], change['age'], change['name'], change['age']))
#             print(f"Inserted/Updated Message: {change}")
#         elif change['operation'] == 'delete':
#             cursor.execute('DELETE FROM consumer WHERE id = %s', (change['id'],))
#             print(f"Deleted Message: {change}")
#         elif change['operation'] == 'update':
#             cursor.execute('UPDATE consumer SET name = %s, age = %s WHERE id = %s', (change['name'], change[''], change['id']))
        

#         conn.commit()

# # Close the PostgreSQL connection
# conn.close()







# from confluent_kafka import Consumer  
# import psycopg2  
# import json  

# # Kafka setup  
# consumer = Consumer({  
#     'bootstrap.servers': 'localhost:9092',  
#     'group.id': 'grp14',  
#     'auto.offset.reset': 'earliest'  
# })  

# consumer.subscribe(['pyscript'])  

# # PostgreSQL setup  
# conn = psycopg2.connect(  
#     host="localhost",  
#     database="postgres",  
#     user="yesitsme",  
#     password="Darshan123"  
# )  

# cursor = conn.cursor()  

# # Create a new table if it doesn't exist  
# cursor.execute('''  
# CREATE TABLE IF NOT EXISTS new_consumer (  
#     id SERIAL PRIMARY KEY,  
#     name VARCHAR(100),  
#     age INT  
# )  
# ''')  

# while True:  
#     print("Polling for messages...")  
#     msg = consumer.poll(1.0)  
#     if msg is None:  
#         print("No messages received")  
#         continue  
#     elif msg.error():  
#         print(f"Error: {msg.error()}")  
#     else:  
#         print("Received message")  
#         change = json.loads(msg.value().decode('utf-8'))  
        
#         # Log the incoming message to see its structure  
#         print(f"Incoming message: {change}")  

#         # Check if the expected keys are present  
#         if 'operation' not in change:  
#             print("Received message does not have 'operation' key, skipping...")  
#             break  

#         # Handle the change based on the operation  
#         if change['operation'] == 'insert':  
#             cursor.execute('''  
#             INSERT INTO new_consumer (id, name, age) VALUES (%s, %s, %s)  
#             ON CONFLICT (id) DO UPDATE SET name = %s, age = %s  
#             ''', (change['id'], change['name'], change['age'], change['name'], change['age']))  
#             print(f"Inserted/Updated Message: {change}")  
#         elif change['operation'] == 'delete':  
#             cursor.execute('DELETE FROM new_consumer WHERE id = %s', (change['id'],))  
#             print(f"Deleted Message: {change}")  
#         elif change['operation'] == 'update':  
#             cursor.execute('UPDATE new_consumer SET name = %s, age = %s WHERE id = %s', (change['name'], change['age'], change['id']))  
#             print(f"Updated Message: {change}")  

#         conn.commit()  

# # Close the PostgreSQL connection  
# conn.close()