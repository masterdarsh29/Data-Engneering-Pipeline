from awsglue.context import GlueContext
from pyspark.context import SparkContext
from pyspark.sql.functions import col, from_json, when
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType
from pyspark.sql import Row
from pyspark.conf import SparkConf
import time
import os
import shutil

# Initialize Spark Context with additional configuration
conf = SparkConf() 
sc = SparkContext(conf=conf)
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# Define the schema of your JSON data
schema = StructType([
    StructField("id", IntegerType(), True),
    StructField("name", StringType(), True),
    StructField("age", IntegerType(), True),
    StructField("operation", StringType(), True),
    StructField("stamp", TimestampType(), True)
])

# Kafka Configuration
kafka_brokers = 'kafka1:29092'
kafka_topic = 'pyscript'

# Initialize an empty DataFrame for your current data
current_data_schema = StructType([
    StructField("id", IntegerType(), True),
    StructField("name", StringType(), True),
    StructField("age", IntegerType(), True),
    StructField("operation", StringType(), True),
    StructField("stamp", TimestampType(), True)
])
output_path = "data"

def load_existing_data():
    if os.path.exists(output_path):
        df = spark.read.schema(current_data_schema).option("header", True).csv(output_path)
        if df.rdd.isEmpty():
            return spark.createDataFrame(spark.sparkContext.emptyRDD(), current_data_schema)
        else:
            return df
    else:
        return spark.createDataFrame(spark.sparkContext.emptyRDD(), current_data_schema)

def process_operations(df):
    global current_data_df  # Use the global DataFrame

    # Merge existing data
    existing_data = load_existing_data()
    current_data_df = existing_data

    for row in df.collect():
        id = row['id']
        name = row['name']
        age = row['age']
        operation = row['operation']
        stamp = row['stamp']

        if operation == 'insert':
            new_row = spark.createDataFrame([Row(id=id, name=name, age=age, operation=operation, stamp=stamp)], schema)
            current_data_df = current_data_df.union(new_row)
            print("Inserted!")
        elif operation == 'update':
            current_data_df = current_data_df.withColumn(
                "name",
                when(col("id") == row["id"], row["name"]).otherwise(col("name"))
            ).withColumn(
                "age",
                when(col("id") == row["id"], row["age"]).otherwise(col("age"))
            ).withColumn(
                "operation",
                when(col("id") == row["id"], row["operation"]).otherwise(col("operation"))
            ).withColumn(
                "stamp",
                when(col("id") == row["id"], row["stamp"]).otherwise(col("stamp"))
            )
            print("Updated!")
        elif operation == 'delete':
            current_data_df = current_data_df.filter(col("id") != id)
            print("Deleted!")

    current_data_df.show()

    # Write to CSV file, overwriting the existing file
    if os.path.exists(output_path):
        shutil.rmtree(output_path)  

    if current_data_df.count() > 0:
        current_data_df = current_data_df.coalesce(1)  # Coalesce to a single file
        current_data_df.write.option("header", True).mode("overwrite").csv(output_path)
    else:
        print("No data to write to CSV")

while True:
    try:
        # Read data from Kafka
        df = spark.read.format("kafka") \
            .option("kafka.bootstrap.servers", kafka_brokers) \
            .option("subscribe", kafka_topic) \
            .load()
            # .option("startingOffsets", "latest") \
            
        # Convert the Kafka message from JSON
        df = df.selectExpr("CAST(value AS STRING) as json_value") \
            .withColumn("json_data", from_json(col("json_value"), schema)) \
            .select("json_data.*")
        # Remove duplicates based on id and timestamp
        df = df.dropDuplicates(["id", "stamp"])
        # Process the operations
        process_operations(df)
    except Exception as e:
        print(f"Error processing data: {e}")
    # Sleep for a short interval to make the loop efficient
    time.sleep(5)

