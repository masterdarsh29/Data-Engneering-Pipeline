# from confluent_kafka import Producer
# import json
# import psycopg2  # PostgreSQL adapter for Python
# import time

 
# # PostgreSQL connection details
# db_params = {
#     'host': 'localhost',       # Hostname of the PostgreSQL server
#     'port': '5432',          # Port of the PostgreSQL server
#     'dbname': 'postgres',        # Database name
#     'user': 'yesitsme',          # Database user
#     'password': 'Darshan123'   # Database password
# }

# # Establish connection to PostgreSQL
# try:
#     conn = psycopg2.connect(**db_params)
#     cursor = conn.cursor()
#     print("PostgreSQL connection successful.")
# except Exception as e:
#     print(f"Error connecting to PostgreSQL: {e}")
#     exit(1)
 
# # Kafka producer configuration
# conf = {
#     'bootstrap.servers': 'localhost:9092'  # Kafka broker address
# }
 
# # Create a Kafka producer
# producer = Producer(conf)
# print("Kafka producer connection successful.")
 
# # Produce messages to Kafka
# try:
#     cursor.execute("SELECT * FROM mytable_audit")
#     rows = cursor.fetchall()
   
#     for row in rows:
#         message = {
            # 'id': row[0],
            # 'name': row[1],
            # 'age': row[2],
            # 'operation': row[3],
            # 'stamp': row[4].isoformat()
#         }
#         # Produce message to Kafka with key as ID
#         producer.produce('pyscript', key=str(message['id']), value=json.dumps(message).encode('utf-8'))
#         print(f"Produced message: {message}")
 
#     producer.flush()

#     print("All messages sent successfully.")
#     time.sleep(3)
# except Exception as e:
#     print(f"Error producing message: {e}")

# finally:
#     cursor.close()
#     conn.close()
 
from confluent_kafka import Producer
import json
import psycopg2
import datetime
import time
 
# PostgreSQL connection details
db_params = {
    'host': 'localhost',
    'port': '5432',
    'dbname': 'postgres',
    'user': 'yesitsme',
    'password': 'Darshan123'
}
 
# Kafka producer configuration
conf = {
    'bootstrap.servers': 'localhost:9092'
}
 
# Kafka topic name
kafka_topic = 'pyscript'
 
# Timestamp file to keep track of last processed entry
timestamp_file = 'last_processed_timestamp.txt'
 
# Function to read the last processed timestamp from the file
def read_last_timestamp():
    try:
        with open(timestamp_file, 'r') as f:
            timestamp_str = f.read().strip()
            return datetime.datetime.fromisoformat(timestamp_str) if timestamp_str else datetime.datetime.min
    except FileNotFoundError:
        return datetime.datetime.min  # Default to Unix epoch if file doesn't exist
 
# Function to update the last processed timestamp in the file
def update_last_timestamp(timestamp):
    with open(timestamp_file, 'w') as f:
        f.write(timestamp.isoformat())
 
# Custom JSON encoder to handle datetime objects
class DateTimeEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (datetime.datetime, datetime.date)):
            return obj.isoformat()
        return super(DateTimeEncoder, self).default(obj)
 
# Establish connection to PostgreSQL
try:
    conn = psycopg2.connect(**db_params)
    cursor = conn.cursor()
    print("PostgreSQL connection successful.")
except Exception as e:
    print(f"Error connecting to PostgreSQL: {e}")
    exit(1)
 
# Create a Kafka producer
producer = Producer(conf)
print("Kafka producer connection successful.")
 
# Get the last processed timestamp
last_timestamp = read_last_timestamp()
 
# Continuously produce messages to Kafka
try:
    while True:
        try:
            # Fetch rows from the customer_audit table where the timestamp is greater than the last processed timestamp
            cursor.execute("SELECT * FROM mytable_audit WHERE stamp > %s ORDER BY stamp ASC", (last_timestamp,))
            rows = cursor.fetchall()
 
            for row in rows:
                message = {
                    'id': row[0],
                    'name': row[1],
                    'age': row[2],
                    'operation': row[3],
                    'stamp': row[4]
                }
                # Produce message to Kafka with key as ID using the custom JSON encoder
                producer.produce(kafka_topic, key=str(message['id']), value=json.dumps(message, cls=DateTimeEncoder).encode('utf-8'))
                print(f"Produced message: {message}")
 
                # Update the last processed timestamp
                if row[4] > last_timestamp:
                    last_timestamp = row[4]  # Update the timestamp
 
            producer.flush()
            print("All messages sent successfully.")
 
            # Update the timestamp file with the latest timestamp
            update_last_timestamp(last_timestamp)
 
        except Exception as e:
            print(f"Error producing message: {e}")
       
        # Sleep for a while before the next iteration to reduce load
        time.sleep(10)
 
finally:
    cursor.close()
    conn.close()

